/*
 * Copyright (C) 2010 Emweb bv, Herent, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/Dbo/SqlConnectionPool.h"

namespace Wt {
  namespace Dbo {

SqlConnectionPool::~SqlConnectionPool()
{ }

  }
}
